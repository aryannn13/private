## Packages
react-simple-code-editor | Lightweight code editor component
prismjs | Syntax highlighting for the code editor
lucide-react | Beautiful icons
date-fns | Formatting dates

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  mono: ["'JetBrains Mono'", "'Fira Code'", "monospace"],
  sans: ["'Inter'", "sans-serif"],
}
